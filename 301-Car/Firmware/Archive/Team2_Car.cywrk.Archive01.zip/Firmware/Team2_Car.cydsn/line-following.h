/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
 */
// Includes
#include <project.h>

// Defines
#define NONE 0
#define DRIVEFORWARD 1
#define CORRECTLEFT 2
#define CORRECTRIGHT 3
#define WAITTURNLEFT 4
#define WAITTURNRIGHT 5
#define TURNCARLEFT 6
#define TURNCARRIGHT 7

#define FLSENSOR 0
#define FMSENSOR 1
#define FRSENSOR 2
#define BLSENSOR 3
#define BRSENSOR 4
#define BMSENSOR 5

#define ONLINE ((1 << FMSENSOR)) //& (1 << BMSENSOR))
#define OFFONLEFT ((1 << FRSENSOR))
#define OFFONRIGHT ((1 << FLSENSOR))
#define TURNUPCOMINGLEFT ((1 << FLSENSOR) & (1 << FMSENSOR))  //& (1 << BMSENSOR))
#define TURNUPCOMINGRIGHT ((1 << FMSENSOR) & (1 << FRSENSOR)) //& (1 << BMSENSOR))
#define TURNLEFT ((1 << BLSENSOR) & (1 << BMSENSOR))
#define TURNRIGHT ((1 << BRSENSOR) & (1 << BMSENSOR))

#define MOVE_SPEED 100
#define CONTROL_SPEED 50
#define TURN_COUNT 111
#define METRE_COUNT 1118

// External variables
extern uint8_t currentState;

// Function definitions
void check_sensors();
void drive_forward();
void correct_left();
void correct_right();
void turn_left();
void turn_right();

/* [] END OF FILE */
