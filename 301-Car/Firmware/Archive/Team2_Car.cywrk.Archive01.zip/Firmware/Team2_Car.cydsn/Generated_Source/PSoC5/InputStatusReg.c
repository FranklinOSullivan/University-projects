/*******************************************************************************
* File Name: InputStatusReg.c  
* Version 1.90
*
* Description:
*  This file contains API to enable firmware to read the value of a Status 
*  Register.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "InputStatusReg.h"

#if !defined(InputStatusReg_sts_sts_reg__REMOVED) /* Check for removal by optimization */


/*******************************************************************************
* Function Name: InputStatusReg_Read
********************************************************************************
*
* Summary:
*  Reads the current value assigned to the Status Register.
*
* Parameters:
*  None.
*
* Return:
*  The current value in the Status Register.
*
*******************************************************************************/
uint8 InputStatusReg_Read(void) 
{ 
    return InputStatusReg_Status;
}


/*******************************************************************************
* Function Name: InputStatusReg_InterruptEnable
********************************************************************************
*
* Summary:
*  Enables the Status Register interrupt.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void InputStatusReg_InterruptEnable(void) 
{
    uint8 interruptState;
    interruptState = CyEnterCriticalSection();
    InputStatusReg_Status_Aux_Ctrl |= InputStatusReg_STATUS_INTR_ENBL;
    CyExitCriticalSection(interruptState);
}


/*******************************************************************************
* Function Name: InputStatusReg_InterruptDisable
********************************************************************************
*
* Summary:
*  Disables the Status Register interrupt.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void InputStatusReg_InterruptDisable(void) 
{
    uint8 interruptState;
    interruptState = CyEnterCriticalSection();
    InputStatusReg_Status_Aux_Ctrl &= (uint8)(~InputStatusReg_STATUS_INTR_ENBL);
    CyExitCriticalSection(interruptState);
}


/*******************************************************************************
* Function Name: InputStatusReg_WriteMask
********************************************************************************
*
* Summary:
*  Writes the current mask value assigned to the Status Register.
*
* Parameters:
*  mask:  Value to write into the mask register.
*
* Return:
*  None.
*
*******************************************************************************/
void InputStatusReg_WriteMask(uint8 mask) 
{
    #if(InputStatusReg_INPUTS < 8u)
    	mask &= ((uint8)(1u << InputStatusReg_INPUTS) - 1u);
	#endif /* End InputStatusReg_INPUTS < 8u */
    InputStatusReg_Status_Mask = mask;
}


/*******************************************************************************
* Function Name: InputStatusReg_ReadMask
********************************************************************************
*
* Summary:
*  Reads the current interrupt mask assigned to the Status Register.
*
* Parameters:
*  None.
*
* Return:
*  The value of the interrupt mask of the Status Register.
*
*******************************************************************************/
uint8 InputStatusReg_ReadMask(void) 
{
    return InputStatusReg_Status_Mask;
}

#endif /* End check for removal by optimization */


/* [] END OF FILE */
