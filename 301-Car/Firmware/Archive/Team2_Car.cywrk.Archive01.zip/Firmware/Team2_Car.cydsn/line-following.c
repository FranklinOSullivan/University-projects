/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
 */
#include "line-following.h"
#include "motorPID.h"

// External variables
uint8_t currentAct;
uint8_t currentState;

// Function prototypes

void follow_line()
{
    // FL, FM, FR
    // BL,   , BR
    //   , MB,
    // Read status register of sensors
    uint8_t sensorVal = InputStatusReg_Read();

    switch (currentState)
    {
    case DRIVEFORWARD:
        drive_forward();
        if (sensorVal & TURNUPCOMINGLEFT)
        {
            currentState = WAITTURNLEFT;
        }
        else if (sensorVal & TURNUPCOMINGRIGHT)
        {
            currentState = WAITTURNRIGHT;
        }
        else if (sensorVal & OFFONLEFT)
        {
            currentState = CORRECTLEFT;
        }
        else if (sensorVal & OFFONRIGHT)
        {
            currentState = CORRECTRIGHT;
        }
        break;

    case CORRECTLEFT:
        correct_left();
        if (sensorVal & ONLINE)
        {
            currentState = DRIVEFORWARD;
        }
        break;
    case CORRECTRIGHT:
        correct_right();
        if (sensorVal & ONLINE)
        {
            currentState = DRIVEFORWARD;
        }
        break;
    case WAITTURNLEFT:
        drive_forward();
        if (sensorVal & TURNLEFT)
        {
            currentState = TURNCARLEFT;
        }
        break;
    case WAITTURNRIGHT:
        drive_forward();
        if (sensorVal & TURNRIGHT)
        {
            currentState = TURNCARRIGHT;
        }
        break;
    case TURNCARLEFT:
        turn_left();
        if (sensorVal & ONLINE)
        {
            currentState = DRIVEFORWARD;
        }
        break;
    case TURNCARRIGHT:
        turn_right();
        if (sensorVal & ONLINE)
        {
            currentState = DRIVEFORWARD;
        }
        break;
    default:
        break;
    }
}

void drive_forward()
{
    setTargetRPM(MOVE_SPEED, FORWARD);
}

void correct_left()
{
    setTargetRPM(MOVE_SPEED, LEFT);
}

void correct_right()
{
    setTargetRPM(MOVE_SPEED, RIGHT);
}

void turn_left()
{
    setTargetRPM(CONTROL_SPEED, LEFT);
}

void turn_right()
{
    setTargetRPM(CONTROL_SPEED, RIGHT);
}

/* [] END OF FILE */
